    <!DOCTYPE html>
    <html>
        <head>
            <meta content="Wolfenstein 3D HTML5" name="description"></meta>
            <meta content="wolfenstein,3d,game,html5,javascript,engine" name="keywords"></meta>
            <title>Wolfenstein 3D</title>
            <link type="text/css" href="css/build.css" rel="stylesheet"></link>
			<script src="js/webkitAudioContextMonkeyPatch.js" type="text/javascript" language="javascript"></script>
            <script async="" src="js/a.js"></script>
            <script language="javascript" type="text/javascript" src="js/build.js"></script>
            <link href="images/favicon.png" type="image/png" rel="shortcut icon"></link>
            <link href="images/favicon.png" type="image/png" rel="icon"></link>
        </head>
        <body oncontextmenu="return false;">
            <div id="resources">
Loading...<br></br>
<img src="images/loading-intersect.png"/>
            </div>
            <audio id="music" preload="true" loop=""></audio>
            <div>
                <div id="copyright" class=" fadein">
                    <div class="content" style="position: fixed; left: 0; top: 0; bottom: 0; right: 0; overflow: auto; padding: 32px;">
                        <div style="width: 100%; text-align: center;">
                            <img src="images/wolfenstein3d-logo.png"></img>
                        </div>
                        <div class="clear"></div>
                        <div id="start" class="text readme" style="cursor: pointer; Color:black;">
<img src="images/start.png"/>                       </div>
                    </div>
                </div>
        </body>
    </html>

