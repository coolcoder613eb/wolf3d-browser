

original repo:https://sourceforge.net/projects/wolfeinstein3dhtml5/



## Description

Wolfeinstein 3D HTML5 full conversion

I did not wrote it i am not the maker of this script.
It is relased under the gplv2 licence.

6 Episode + Spear of Destiny

Usage: Just upload and play!

This is a total html5-javascript-JSON conversion of
the original game, all episodes until Spear of Destiny
is included! 81 stage.

Usage:
1. Upload to any webhost
2. Load the index.php in your web browser
(what is should be webkit/webgl capable)
3. It can save the game and store it in JSON
and cookies.

What is not working:

1. Sound and music volume control
(Once you turn off in the menu you cannot turn
back on any sound just if u erase all cookies)

2. Quit menu option(it figures why not... XD)

3. Function keyboards(F1 to F12) are not working.

The script itself is opensource, so you can rewrite
from scratch change and edit levels and graphics,
to make your own game!

Have fun!

## Features

- Full 3D raycast Engine
- All 81 levels 6 episode + Spear of destiny + Pacman level
- Total Javascript + Json not need any emulation
- Works both Chrome and Firefox and Nightly, or any webgl/canvas capable browser

### Project Samples

![Title Screen](/screenshots/wolfenstein1.gif)





![Ingame 1](/screenshots/wolfenstein4.jpg)

![Ingame 2](/screenshots/wolfenstein2.jpg)

![Ingame 3](/screenshots/wolfenstein3.jpg)




